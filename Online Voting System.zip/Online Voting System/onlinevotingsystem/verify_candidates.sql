USE online_voting;

-- Check if candidates exist
SELECT COUNT(*) as candidate_count FROM candidates;

-- Insert candidates if they don't exist
INSERT INTO candidates (name, party, position)
SELECT 'John Doe', 'Democratic Party', 'President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'John Doe' AND position = 'President');

INSERT INTO candidates (name, party, position)
SELECT 'Jane Smith', 'Republican Party', 'President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Jane Smith' AND position = 'President');

INSERT INTO candidates (name, party, position)
SELECT 'Mike Johnson', 'Independent', 'Vice President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Mike Johnson' AND position = 'Vice President');

INSERT INTO candidates (name, party, position)
SELECT 'Sarah Williams', 'Green Party', 'Vice President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Sarah Williams' AND position = 'Vice President');

-- Verify candidates after insertion
SELECT * FROM candidates; 