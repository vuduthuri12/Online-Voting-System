-- Create database if not exists
CREATE DATABASE IF NOT EXISTS online_voting;
USE online_voting;

-- Drop tables in correct order (respecting foreign key constraints)
DROP TABLE IF EXISTS votes;
DROP TABLE IF EXISTS candidates;
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    voter_id VARCHAR(20) UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'voter'
);

-- Create candidates table
CREATE TABLE candidates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    party VARCHAR(50) NOT NULL,
    position VARCHAR(50) NOT NULL
);

-- Create votes table
CREATE TABLE votes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    candidate_id INT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- Insert admin user
INSERT INTO users (username, password, full_name, voter_id, role)
VALUES ('admin', 'admin123', 'System Administrator', 'ADMIN001', 'admin')
ON DUPLICATE KEY UPDATE username = username;

-- Insert test candidates
INSERT INTO candidates (name, party, position) VALUES
('John Smith', 'Democratic Party', 'President'),
('Jane Doe', 'Republican Party', 'President'),
('Bob Wilson', 'Independent', 'President'),
('Alice Brown', 'Democratic Party', 'Vice President'),
('Charlie Davis', 'Republican Party', 'Vice President');

-- Insert test votes (if needed)
INSERT INTO votes (user_id, candidate_id)
SELECT u.id, c.id
FROM users u
CROSS JOIN candidates c
WHERE u.username = 'admin'
LIMIT 1; 