package com.voting.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.voting.util.DBUtil;

public class VoteDAO {
    public boolean hasVoted(int userId) throws SQLException {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM votes WHERE user_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
    }

    public boolean recordVote(int userId, int candidateId) throws SQLException {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO votes (user_id, candidate_id) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, userId);
            ps.setInt(2, candidateId);
            return ps.executeUpdate() > 0;
        }
    }

    public List<VoteResult> getVoteResults() throws SQLException {
        List<VoteResult> results = new ArrayList<>();
        String sql = "SELECT c.id, c.name, c.party, c.position, COUNT(v.id) as vote_count " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "GROUP BY c.id, c.name, c.party, c.position " +
                    "ORDER BY c.position, vote_count DESC";
                    
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                VoteResult result = new VoteResult();
                result.setCandidateId(rs.getInt("id"));
                result.setCandidateName(rs.getString("name"));
                result.setParty(rs.getString("party"));
                result.setPosition(rs.getString("position"));
                result.setVotes(rs.getInt("vote_count"));
                results.add(result);
            }
        }
        return results;
    }

    public Map<String, Integer> getOverallVoteCounts() throws SQLException {
        Map<String, Integer> voteCounts = new HashMap<>();
        String sql = "SELECT c.name, COUNT(v.id) as total_votes " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "GROUP BY c.id, c.name " +
                    "ORDER BY total_votes DESC";
                    
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                voteCounts.put(rs.getString("name"), rs.getInt("total_votes"));
            }
        }
        return voteCounts;
    }

    public int getTotalVotes() throws SQLException {
        System.out.println("[VoteDAO] Getting total votes...");
        String sql = "SELECT COUNT(*) as total FROM votes";
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("[VoteDAO] Executed SQL: " + sql);
            
            if (rs.next()) {
                int total = rs.getInt("total");
                System.out.println("[VoteDAO] Total votes found: " + total);
                return total;
            }
            System.out.println("[VoteDAO] No votes found, returning 0");
            return 0;
        } catch (SQLException e) {
            System.out.println("[VoteDAO] Error getting total votes: " + e.getMessage());
            throw e;
        }
    }

    public List<Map<String, Object>> getCandidateVoteDetails() throws SQLException {
        List<Map<String, Object>> details = new ArrayList<>();
        String sql = "SELECT c.name, c.party, COUNT(v.id) as votes, " +
                    "ROUND(COUNT(v.id) * 100.0 / (SELECT COUNT(*) FROM votes), 1) as percentage " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "GROUP BY c.id, c.name, c.party " +
                    "ORDER BY votes DESC";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Map<String, Object> detail = new HashMap<>();
                detail.put("name", rs.getString("name"));
                detail.put("party", rs.getString("party"));
                detail.put("votes", rs.getInt("votes"));
                detail.put("percentage", rs.getDouble("percentage"));
                details.add(detail);
            }
        }
        return details;
    }

    public static class VoteResult {
        private int candidateId;
        private String candidateName;
        private String party;
        private String position;
        private int votes;
        
        // Getters and Setters
        public int getCandidateId() { return candidateId; }
        public void setCandidateId(int candidateId) { this.candidateId = candidateId; }
        public String getCandidateName() { return candidateName; }
        public void setCandidateName(String candidateName) { this.candidateName = candidateName; }
        public String getParty() { return party; }
        public void setParty(String party) { this.party = party; }
        public String getPosition() { return position; }
        public void setPosition(String position) { this.position = position; }
        public int getVotes() { return votes; }
        public void setVotes(int votes) { this.votes = votes; }
    }
}
