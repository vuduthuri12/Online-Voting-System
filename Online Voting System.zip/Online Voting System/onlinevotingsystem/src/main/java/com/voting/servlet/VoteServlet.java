package com.voting.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.voting.dao.VoteDAO;
import com.voting.model.User;

public class VoteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private VoteDAO voteDAO;
    
    public void init() {
        voteDAO = new VoteDAO();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        // Check if user is logged in and is a voter
        if (user == null || "admin".equals(user.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String candidateIdStr = request.getParameter("candidateId");
        if (candidateIdStr == null || candidateIdStr.trim().isEmpty()) {
            request.setAttribute("error", "Please select a candidate to vote for.");
            request.getRequestDispatcher("vote.jsp").forward(request, response);
            return;
        }
        
        try {
            int candidateId = Integer.parseInt(candidateIdStr);
            
            // Check if user has already voted
            if (voteDAO.hasVoted(user.getId())) {
                request.setAttribute("error", "You have already cast your vote.");
                request.getRequestDispatcher("vote.jsp").forward(request, response);
                return;
            }
            
            // Record the vote
            if (voteDAO.recordVote(user.getId(), candidateId)) {
                // Set a success message in the session
                session.setAttribute("votingSuccess", true);
                // Redirect to thank you page
                response.sendRedirect("thank-you.jsp");
            } else {
                request.setAttribute("error", "Failed to record your vote. Please try again.");
                request.getRequestDispatcher("vote.jsp").forward(request, response);
            }
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid candidate selection.");
            request.getRequestDispatcher("vote.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "An error occurred while processing your vote.");
            request.getRequestDispatcher("vote.jsp").forward(request, response);
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        // Check if user is logged in and is an admin
        if (user == null || !"admin".equals(user.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        try {
            // Get detailed results by position
            request.setAttribute("voteResults", voteDAO.getVoteResults());
            
            // Get overall vote counts for all candidates
            request.setAttribute("overallVotes", voteDAO.getOverallVoteCounts());
            
            // Get total number of votes cast
            request.setAttribute("totalVotes", voteDAO.getTotalVotes());
            
            request.getRequestDispatcher("results.jsp").forward(request, response);
        } catch (SQLException e) {
            request.setAttribute("error", "Error retrieving vote results.");
            request.getRequestDispatcher("results.jsp").forward(request, response);
        }
    }
}
