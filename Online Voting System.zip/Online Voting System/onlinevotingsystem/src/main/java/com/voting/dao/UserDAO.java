package com.voting.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.voting.model.User;
import com.voting.util.DBUtil;

public class UserDAO {
    public User login(String username, String password) {
        try (Connection con = DBUtil.getConnection()) {
            System.out.println("\n=== Login Attempt Debug ===");
            System.out.println("Username: [" + username + "]");
            System.out.println("Password: [" + password + "]");
            System.out.println("Password length: " + (password != null ? password.length() : 0));
            System.out.println("Database connection successful");
            
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            System.out.println("Executing query: " + sql);
            System.out.println("Parameters - Username: [" + username + "], Password: [" + password + "]");
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setRole(rs.getString("role"));
                u.setEmail(rs.getString("email"));
                u.setFullName(rs.getString("full_name"));
                u.setVoterId(rs.getString("voter_id"));
                
                System.out.println("Login successful!");
                System.out.println("User details:");
                System.out.println("- ID: " + u.getId());
                System.out.println("- Username: [" + u.getUsername() + "]");
                System.out.println("- Role: [" + u.getRole() + "]");
                System.out.println("- Email: [" + u.getEmail() + "]");
                return u;
            } else {
                System.out.println("Login failed: No matching user found");
                // Let's check if the username exists at all
                String checkUserSql = "SELECT * FROM users WHERE username=?";
                PreparedStatement checkPs = con.prepareStatement(checkUserSql);
                checkPs.setString(1, username);
                ResultSet checkRs = checkPs.executeQuery();
                if (checkRs.next()) {
                    System.out.println("Username exists but password doesn't match");
                    System.out.println("Stored username: [" + checkRs.getString("username") + "]");
                    System.out.println("Stored password: [" + checkRs.getString("password") + "]");
                    System.out.println("Stored password length: " + checkRs.getString("password").length());
                } else {
                    System.out.println("Username not found in database");
                }
            }
        } catch (SQLException e) {
            System.out.println("Database error during login: " + e.getMessage());
            System.out.println("SQL State: " + e.getSQLState());
            System.out.println("Error Code: " + e.getErrorCode());
            e.printStackTrace();
        }
        return null;
    }

    public boolean isUsernameExists(String username) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM users WHERE username=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isEmailExists(String email) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM users WHERE email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isVoterIdExists(String voterId) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM users WHERE voter_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, voterId);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean register(User user) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO users(username, password, role, email, full_name, voter_id) VALUES(?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, "voter"); // Default role for new registrations
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getFullName());
            ps.setString(6, user.getVoterId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public int getTotalVoters() throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE role = 'voter'";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
}

