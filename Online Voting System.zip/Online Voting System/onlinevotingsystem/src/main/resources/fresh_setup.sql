-- Drop and recreate database
DROP DATABASE IF EXISTS online_voting;
CREATE DATABASE online_voting;
USE online_voting;

-- Create users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    voter_id VARCHAR(50) UNIQUE NOT NULL
);

-- Create candidates table
CREATE TABLE candidates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    party VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL
);

-- Create votes table
CREATE TABLE votes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    candidate_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- Insert admin user
INSERT INTO users (username, password, role, email, full_name, voter_id)
VALUES ('admin', 'admin123', 'admin', 'admin@example.com', 'System Administrator', 'ADMIN001');

-- Insert two candidates (one from each party)
INSERT INTO candidates (name, party, position) VALUES
('John Smith', 'Democratic Party', 'President'),
('Jane Doe', 'Republican Party', 'President');

-- Insert sample voters
INSERT INTO users (username, password, role, email, full_name, voter_id) VALUES
('voter1', 'pass123', 'voter', 'voter1@example.com', 'Alice Johnson', 'VOTER001'),
('voter2', 'pass123', 'voter', 'voter2@example.com', 'Bob Wilson', 'VOTER002'),
('voter3', 'pass123', 'voter', 'voter3@example.com', 'Carol Brown', 'VOTER003');

-- Record some sample votes
INSERT INTO votes (user_id, candidate_id) VALUES
(2, 1), -- voter1 voted for John Smith
(3, 2), -- voter2 voted for Jane Doe
(4, 1); -- voter3 voted for John Smith

-- Verify the data
SELECT 'Users:' as '';
SELECT * FROM users;

SELECT 'Candidates:' as '';
SELECT * FROM candidates;

SELECT 'Votes:' as '';
SELECT u.username, c.name as candidate_name, c.party, v.created_at
FROM votes v
JOIN users u ON v.user_id = u.id
JOIN candidates c ON v.candidate_id = c.id; 