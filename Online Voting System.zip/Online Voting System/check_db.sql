USE online_voting;

-- Show all users
SELECT * FROM users;

-- Update admin password if needed
UPDATE users 
SET password = 'admin123' 
WHERE username = 'admin';

-- Show admin user
SELECT * FROM users WHERE username = 'admin'; 