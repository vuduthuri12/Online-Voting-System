-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS online_voting;
USE online_voting;

-- Create users table if not exists
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    voter_id VARCHAR(50) UNIQUE NOT NULL
);

-- Add email column if it doesn't exist
SET @dbname = 'online_voting';
SET @tablename = 'users';
SET @columnname = 'email';
SET @preparedStatement = (SELECT IF(
    (
        SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_SCHEMA = @dbname
        AND TABLE_NAME = @tablename
        AND COLUMN_NAME = @columnname
    ) > 0,
    "SELECT 1",
    "ALTER TABLE users ADD COLUMN email VARCHAR(100) UNIQUE"
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Create candidates table if not exists
CREATE TABLE IF NOT EXISTS candidates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    party VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL
);

-- Create votes table if not exists
CREATE TABLE IF NOT EXISTS votes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    candidate_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (candidate_id) REFERENCES candidates(id)
);

-- Insert admin user if not exists
INSERT INTO users (username, password, role, full_name, voter_id)
SELECT 'admin', 'admin123', 'admin', 'System Administrator', 'ADMIN001'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin');

-- Update admin email if exists
UPDATE users SET email = 'admin@example.com' WHERE username = 'admin' AND email IS NULL;

-- Insert sample candidates if not exists
INSERT INTO candidates (name, party, position)
SELECT 'John Doe', 'Democratic Party', 'President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'John Doe' AND position = 'President');

INSERT INTO candidates (name, party, position)
SELECT 'Jane Smith', 'Republican Party', 'President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Jane Smith' AND position = 'President');

INSERT INTO candidates (name, party, position)
SELECT 'Mike Johnson', 'Independent', 'Vice President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Mike Johnson' AND position = 'Vice President');

INSERT INTO candidates (name, party, position)
SELECT 'Sarah Williams', 'Green Party', 'Vice President'
WHERE NOT EXISTS (SELECT 1 FROM candidates WHERE name = 'Sarah Williams' AND position = 'Vice President'); 