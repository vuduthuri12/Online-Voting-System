package com.voting.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.voting.dao.UserDAO;
import com.voting.model.User;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;

    public void init() {
        userDAO = new UserDAO();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        System.out.println("\n=== Login Attempt Debug ===");
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        System.out.println("[LoginServlet] Login attempt for username: " + username);
        System.out.println("[LoginServlet] Password length: " + (password != null ? password.length() : 0));
        
        if (username == null || username.trim().isEmpty() || 
            password == null || password.trim().isEmpty()) {
            System.out.println("[LoginServlet] ERROR: Username or password is empty");
            request.setAttribute("error", "Username and password are required");
            request.getRequestDispatcher("login.jsp").forward(request, response);
            return;
        }

        try {
            System.out.println("[LoginServlet] Attempting to authenticate user...");
            User user = userDAO.login(username.trim(), password.trim());
            
            if (user != null) {
                System.out.println("[LoginServlet] Authentication successful for user: " + user.getUsername());
                System.out.println("[LoginServlet] User role: " + user.getRole());
                
                HttpSession session = request.getSession();
                session.setAttribute("user", user);
                session.setAttribute("username", user.getUsername());
                session.setAttribute("role", user.getRole());
                
                System.out.println("[LoginServlet] Session created with ID: " + session.getId());
                
                if ("admin".equals(user.getRole())) {
                    System.out.println("[LoginServlet] Redirecting to admin dashboard");
                    response.sendRedirect("admin/dashboard.jsp");
                } else {
                    System.out.println("[LoginServlet] Redirecting to voter dashboard");
                    response.sendRedirect("voter/dashboard.jsp");
                }
            } else {
                System.out.println("[LoginServlet] ERROR: Authentication failed - Invalid credentials");
                request.setAttribute("error", "Invalid username or password");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            System.err.println("[LoginServlet] ERROR: Exception during login");
            System.err.println("[LoginServlet] Error message: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "An error occurred during login. Please try again.");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
        
        System.out.println("=== End Login Attempt Debug ===\n");
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("LoginServlet.doGet() - Redirecting to login.jsp");
        response.sendRedirect("login.jsp");
    }
}
