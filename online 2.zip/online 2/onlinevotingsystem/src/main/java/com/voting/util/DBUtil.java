package com.voting.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/online_voting?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "password@12";

    static {
        try {
            System.out.println("[DBUtil] Loading MySQL JDBC Driver...");
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("[DBUtil] MySQL JDBC Driver loaded successfully");
        } catch (ClassNotFoundException e) {
            System.err.println("[DBUtil] ERROR: MySQL JDBC Driver not found!");
            e.printStackTrace();
            throw new RuntimeException("MySQL JDBC Driver not found.", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            System.out.println("\n=== Database Connection Debug ===");
            System.out.println("[DBUtil] Attempting to connect to database...");
            System.out.println("[DBUtil] URL: " + URL);
            System.out.println("[DBUtil] User: " + USER);
            System.out.println("[DBUtil] Password length: " + (PASSWORD != null ? PASSWORD.length() : 0));
            
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("[DBUtil] Database connection successful!");
            System.out.println("[DBUtil] Connection URL: " + conn.getMetaData().getURL());
            System.out.println("[DBUtil] Database Product Name: " + conn.getMetaData().getDatabaseProductName());
            System.out.println("[DBUtil] Database Product Version: " + conn.getMetaData().getDatabaseProductVersion());
            System.out.println("=== End Database Connection Debug ===\n");
            return conn;
        } catch (SQLException e) {
            System.err.println("\n=== Database Connection Error ===");
            System.err.println("[DBUtil] ERROR: Failed to connect to database!");
            System.err.println("[DBUtil] Error message: " + e.getMessage());
            System.err.println("[DBUtil] SQL State: " + e.getSQLState());
            System.err.println("[DBUtil] Error Code: " + e.getErrorCode());
            e.printStackTrace();
            System.err.println("=== End Database Connection Error ===\n");
            throw new SQLException("Failed to connect to database", e);
        }
    }
}
