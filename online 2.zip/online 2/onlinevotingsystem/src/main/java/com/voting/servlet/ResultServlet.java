package com.voting.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.voting.dao.VoteDAO;
import com.voting.model.User;

public class ResultServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private VoteDAO voteDAO;
    
    public void init() {
        voteDAO = new VoteDAO();
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ResultServlet] Processing GET request...");
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            System.out.println("[ResultServlet] No session or user found, redirecting to login");
            response.sendRedirect("login.jsp");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        if (!"admin".equals(user.getRole())) {
            System.out.println("[ResultServlet] User is not admin, redirecting to vote page");
            response.sendRedirect("vote.jsp");
            return;
        }
        
        try {
            System.out.println("[ResultServlet] Getting vote results...");
            // Get detailed results by position
            List<VoteDAO.VoteResult> voteResults = voteDAO.getVoteResults();
            request.setAttribute("voteResults", voteResults);
            System.out.println("[ResultServlet] Vote results: " + voteResults);
            
            System.out.println("[ResultServlet] Getting overall vote counts...");
            // Get overall vote counts for all candidates
            Map<String, Integer> overallVotes = voteDAO.getOverallVoteCounts();
            request.setAttribute("overallVotes", overallVotes);
            System.out.println("[ResultServlet] Overall votes: " + overallVotes);
            
            System.out.println("[ResultServlet] Getting total votes...");
            // Get total number of votes cast
            int totalVotes = voteDAO.getTotalVotes();
            request.setAttribute("totalVotes", totalVotes);
            System.out.println("[ResultServlet] Total votes: " + totalVotes);
            
            System.out.println("[ResultServlet] Forwarding to results.jsp");
            RequestDispatcher rd = request.getRequestDispatcher("results.jsp");
            rd.forward(request, response);
        } catch (SQLException e) {
            System.out.println("[ResultServlet] Error: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("error", "Error retrieving results: " + e.getMessage());
            request.setAttribute("debugException", e);
            request.getRequestDispatcher("results.jsp").forward(request, response);
        }
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect POST requests to GET
        doGet(request, response);
    }
}
