package com.voting.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.voting.model.Candidate;
import com.voting.util.DBUtil;

public class CandidateDAO {
    public List<Candidate> getAllCandidates() throws SQLException {
        List<Candidate> candidates = new ArrayList<>();
        String sql = "SELECT c.*, COUNT(v.id) as vote_count " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "GROUP BY c.id, c.name, c.party";
                    
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Candidate candidate = new Candidate();
                candidate.setId(rs.getInt("id"));
                candidate.setName(rs.getString("name"));
                candidate.setParty(rs.getString("party"));
                candidate.setVoteCount(rs.getInt("vote_count"));
                candidates.add(candidate);
            }
        }
        return candidates;
    }
    
    public Candidate getCandidateById(int id) throws SQLException {
        String sql = "SELECT c.*, COUNT(v.id) as vote_count " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "WHERE c.id = ? " +
                    "GROUP BY c.id, c.name, c.party";
                    
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Candidate candidate = new Candidate();
                    candidate.setId(rs.getInt("id"));
                    candidate.setName(rs.getString("name"));
                    candidate.setParty(rs.getString("party"));
                    candidate.setVoteCount(rs.getInt("vote_count"));
                    return candidate;
                }
            }
        }
        return null;
    }
    
    public boolean addCandidate(Candidate candidate) throws SQLException {
        String sql = "INSERT INTO candidates (name, party) VALUES (?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, candidate.getName());
            stmt.setString(2, candidate.getParty());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public boolean updateCandidate(Candidate candidate) throws SQLException {
        String sql = "UPDATE candidates SET name = ?, party = ? WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, candidate.getName());
            stmt.setString(2, candidate.getParty());
            stmt.setInt(3, candidate.getId());
            return stmt.executeUpdate() > 0;
        }
    }
    
    public boolean deleteCandidate(int id) throws SQLException {
        String sql = "DELETE FROM candidates WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    public int getTotalCandidates() throws SQLException {
        String sql = "SELECT COUNT(*) FROM candidates";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    public Map<String, Integer> getResults() throws SQLException {
        Map<String, Integer> results = new HashMap<>();
        String sql = "SELECT c.party, COUNT(v.id) as vote_count " +
                    "FROM candidates c " +
                    "LEFT JOIN votes v ON c.id = v.candidate_id " +
                    "GROUP BY c.party";
                    
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                results.put(rs.getString("party"), rs.getInt("vote_count"));
            }
        }
        return results;
    }

    public boolean updateVotes(int candidateId) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE candidates SET votes = votes + 1 WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, candidateId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
