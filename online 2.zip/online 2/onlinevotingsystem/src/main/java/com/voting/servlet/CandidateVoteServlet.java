package com.voting.servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.voting.dao.CandidateDAO;
import com.voting.model.Candidate;

public class CandidateVoteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CandidateDAO candidateDAO;

    public void init() {
        candidateDAO = new CandidateDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        
        // Check if user is logged in and is a voter
        if (session == null || session.getAttribute("user") == null || 
            !session.getAttribute("userType").equals("voter")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            // Get all candidates from database
            List<Candidate> candidates = candidateDAO.getAllCandidates();
            request.setAttribute("candidates", candidates);
            
            // Forward to the candidate voting page
            request.getRequestDispatcher("/candidate-vote.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("error", "Error loading candidates: " + e.getMessage());
            request.getRequestDispatcher("/candidate-vote.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
} 