# Create necessary directories
New-Item -ItemType Directory -Force -Path "WebContent\WEB-INF\lib"
New-Item -ItemType Directory -Force -Path "WebContent\WEB-INF\classes\com\voting\dao"
New-Item -ItemType Directory -Force -Path "WebContent\WEB-INF\classes\com\voting\model"
New-Item -ItemType Directory -Force -Path "WebContent\WEB-INF\classes\com\voting\servlet"
New-Item -ItemType Directory -Force -Path "WebContent\WEB-INF\classes\com\voting\util"
New-Item -ItemType Directory -Force -Path "WebContent\css"
New-Item -ItemType Directory -Force -Path "WebContent\js"

# Move JSP files
Move-Item -Path "*.jsp" -Destination "WebContent\" -Force

# Move JAR files
Move-Item -Path "WEB-INF\lib\*" -Destination "WebContent\WEB-INF\lib\" -Force

# Move web.xml
Move-Item -Path "WEB-INF\web.xml" -Destination "WebContent\WEB-INF\" -Force

# Move source files to src directory
New-Item -ItemType Directory -Force -Path "src\main\java\com\voting\dao"
New-Item -ItemType Directory -Force -Path "src\main\java\com\voting\model"
New-Item -ItemType Directory -Force -Path "src\main\java\com\voting\servlet"
New-Item -ItemType Directory -Force -Path "src\main\java\com\voting\util"

# Compile Java files
$classpath = "WebContent\WEB-INF\lib\*"
$sourceDir = "src\main\java"
$outputDir = "WebContent\WEB-INF\classes"

# Create WAR file
Set-Location WebContent
jar -cf ..\onlinevotingsystem.war *
Set-Location .. 